console.log('Script is running...');
const input = document.querySelector('#input');
const button = document.querySelector('#button');
const paragraph = document.querySelector('#paragraph');

button.addEventListener('click', () => {
    console.log('click!');
    if (input.value !== '') {
        paragraph.innerText = input.value;
    }
})